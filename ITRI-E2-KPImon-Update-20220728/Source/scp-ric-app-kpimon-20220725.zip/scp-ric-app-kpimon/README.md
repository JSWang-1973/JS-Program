# kpimon
KPIMON xApp for Bronze Release

# Image Build

```
$ docker build . --tag kpimon:{TAG} --no-cache
```
